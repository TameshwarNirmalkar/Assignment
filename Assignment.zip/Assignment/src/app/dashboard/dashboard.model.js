module.exports = function() {
    return {
        id: undefined,
        title: '',
        author: '',
        gender: undefined
    };
};
