# ES6Babel

## npm install
## npm start app
## json-server db.json --routes routes.json --port 4001  to start database